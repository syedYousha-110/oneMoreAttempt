package com.gluonMobile.views;

import com.gluonMobile.model.Enum.RegionalURL;
import com.gluonMobile.model.SignIn;
import com.gluonMobile.model.SignUp;
import com.gluonhq.attach.keyboard.KeyboardService;
import com.gluonhq.attach.lifecycle.LifecycleService;
import com.gluonhq.charm.glisten.animation.BounceInDownTransition;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.When;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import java.util.Arrays;
import java.util.stream.Collectors;

import static com.gluonMobile.MobileApplication.API_VIEW;

public class RegistrationPresenter{

        @FXML
        private Button BackButton;

        @FXML
        private Label MessageLabel;

        @FXML
        private Button QuitButton;

        @FXML
        private Button SubmitButton;
        @FXML
        private TextField USER_APIKEY;

        @FXML
        private TextField USER_ApiUserEmail;

        @FXML
        private PasswordField USER_ConfirmPassword;

        @FXML
        private TextField USER_FirstName;

        @FXML
        private TextField USER_LastName;

        @FXML
        private TextField USER_Name;

        @FXML
        private PasswordField USER_Password;

        @FXML
        private View register;

        private SignUp signUp;
        @FXML
        private ChoiceBox<RegionalURL> USER_RegionListBox;
        @FXML
        private AnchorPane anchorPaneContainer;

        @FXML
        private ScrollPane scrollPane;

        private SignIn signIn;

        public void initialize(){
                SubmitButton.setOnAction(actionEvent -> {
                        signIn();
                });
                QuitButton.setOnAction(actionEvent -> {
                        LifecycleService.create().ifPresent(LifecycleService::shutdown);
                });
                clearText();
                register.setShowTransitionFactory(BounceInDownTransition::new);
                ObservableList<RegionalURL> user_regionObservableList = FXCollections.observableList(Arrays.stream(RegionalURL.values()).collect(Collectors.toList()));
                USER_RegionListBox.setItems(user_regionObservableList);
                USER_RegionListBox.setValue(RegionalURL.PAKISTAN);
                register.showingProperty().addListener((observable,previous,newValue)->{
                        if (newValue)
                        {
                                anchorPaneContainer.minHeightProperty().addListener(((observableValue, number, t1) -> {
                                        System.out.println(number);
                                        System.out.println(t1);
                                        if (!number.equals(t1)){
                                                scrollPane.setVvalue(0d);
                                        }

                                }));
                                anchorPaneContainer.setMinHeight(1000d);

                                KeyboardService.create().ifPresentOrElse(keyboardService -> {
                                        scrollPane.setVvalue(0d);
                                        keyboardService.visibleHeightProperty().addListener(((observableValue, number, t1) -> {
                                                anchorPaneContainer.setMaxHeight(anchorPaneContainer.getHeight()+t1.doubleValue());
                                        }));
                                },()->{
                                        System.out.println("tune");
                                        //anchorPaneContainer.setMaxHeight(maxHeight);
                                });



                              /*  var translateY = AppManager.getInstance().getGlassPane().getTranslateY();
                                var height = AppManager.getInstance().getGlassPane().getHeight();*/
                               /* AnchorPaneContainer.translateYProperty().bind(Bindings.when(USER_ApiUserEmail.focusedProperty().
                                        or(USER_APIKEY.focusedProperty())).then((-1/3f)*(height)).otherwise(translateY)
                                );*/
                                AppBar appBar = AppManager.getInstance().getAppBar();
                                appBar.setTitle(new Text("Sign UP"));
                                System.out.println("new");
                                this.initialize();


                        }
                });
                When textEqualCondition = Bindings.when(USER_ConfirmPassword.textProperty()
                                .isEqualTo(USER_Password.textProperty()));
                When textLengthCondition = Bindings.when(USER_ConfirmPassword.textProperty().length().greaterThanOrEqualTo(1));
                MessageLabel.visibleProperty().bind(textLengthCondition.then(true).otherwise(false));
                MessageLabel.textProperty().bind(textEqualCondition.then("PasswordMatches")
                        .otherwise("Password does not Match"));
                MessageLabel.textFillProperty().bind(textEqualCondition.then(Color.GREEN).
                        otherwise(Color.RED));
                backOnActionButton(BackButton);
        }

        private void signIn() {
                signUp =  new SignUp();
                signUp.setUSER_NAME(USER_Name.getText());
                signUp.setUSER_FIRSTNAME(USER_FirstName.getText());
                signUp.setUSER_LASTNAME(USER_LastName.getText());
                signUp.setREGION(USER_RegionListBox.getSelectionModel().getSelectedItem());
                signUp.setUSER_APIKEY( USER_APIKEY.getText());
                signUp.setUSER_ApiUserEmail( USER_ApiUserEmail.getText());
                signUp.setUSER_PASSWORD(USER_Password.getText());
                signUp.setUSER_ConfirmPassword( USER_ConfirmPassword.getText());
                this.signIn = new SignIn(signUp);
                AppManager.getInstance().switchView(API_VIEW);
        }

        private void backOnActionButton(Button back){
                back.setOnAction(actionEvent -> {
                        AppManager.getInstance().switchToPreviousView();
                });
        }
        private void clearText(){
                USER_Name.clear();
                USER_FirstName.clear();
                USER_LastName.clear();
                USER_ApiUserEmail.clear();
                USER_APIKEY.clear();
                USER_Password.clear();
                USER_ConfirmPassword.clear();

        }

}
