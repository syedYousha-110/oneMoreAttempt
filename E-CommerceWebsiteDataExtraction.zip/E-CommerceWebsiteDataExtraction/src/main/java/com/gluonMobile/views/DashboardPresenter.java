package com.gluonMobile.views;


import com.gluonMobile.model.DarazSellerModel.GetRequest.ApiGetRequest;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GetOrders;
import com.gluonMobile.model.Enum.APIConstants;
import com.gluonMobile.model.TableModelData.CustomTableProperty;
import com.gluonMobile.model.TableModelData.OrdersTableData;
import com.gluonMobile.model.TableModelData.CustomTableView;
import com.gluonhq.charm.glisten.animation.BounceInRightTransition;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

public class DashboardPresenter {
    @FXML
    public BarChart analytics_chart;

    public View dashboard;

    @FXML
    private Label IncomeLabel;

    @FXML
    private TableView<CustomTableProperty> OrderTable;

    @FXML
    private LineChart<?, ?> RevenuChart;

    @FXML
    private Label additionIncomeLabel;

    @FXML
    private Label expenseLabel;

    @FXML
    private Label extraExpenseLabel;

    @FXML
    private Label percentageProfit;

    @FXML
    private Label priceItem;

    @FXML
    private Label totalRevenue;
    @FXML
    private StackPane TablePane;

    private OrdersTableData tableData;

    private ObservableList<CustomTableProperty> observableList;
    public void initialize(){
        this.tableData = new OrdersTableData();
        GetOrders orders = new GetOrders();
        OrderTableCall call = new OrderTableCall(orders,tableData);
        observableList = FXCollections.observableArrayList();
        dashboard.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = AppManager.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e ->
                        AppManager.getInstance().getDrawer().open()));
                appBar.setTitleText("DASHBOARD");
                TextField field = new TextField();
                var design = MaterialDesignIcon.SEARCH.button();
                appBar.getActionItems().add(design);
                design.setOnAction(event -> {
                    appBar.getActionItems().add(field);
                    appBar.getActionItems().remove(design);
                });
                call.restart();

            }

        });
    }
    private class OrderTableCall extends Service<ApiGetRequest> {

        private final ApiGetRequest apiGetRequest;
        private final CustomTableProperty property;
        public OrderTableCall(ApiGetRequest apiGetRequest, CustomTableProperty property){
            this.apiGetRequest = apiGetRequest;
            this.property = property;
        }
        @Override
        protected Task<ApiGetRequest> createTask() {
            return new Task<>() {
                @Override
                protected ApiGetRequest call() {
                    ApiGetRequest api = apiGetRequest;
                    api.start();
                    try {
                        api.join();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    return api;
                }

            };

        }

        @Override
        protected void succeeded() {
            dashboard.setShowTransitionFactory(BounceInRightTransition::new);
            ObservableList<CustomTableProperty> collection = FXCollections.observableArrayList();
            boolean b = collection.addAll(getValue().getDataForTable());
            observableList = FXCollections.observableArrayList(collection);
            System.out.println(getValue().getDataForTable());
            CustomTableView newTable = new CustomTableView(property,observableList);
            newTable.passInstanceVar(OrderTable);
            OrderTable = newTable.tableView();
            ApiPresenter.tableFunction(OrderTable);
        }
    }


}
