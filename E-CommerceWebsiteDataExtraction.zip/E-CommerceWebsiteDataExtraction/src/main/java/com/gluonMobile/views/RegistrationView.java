package com.gluonMobile.views;

import com.airhacks.afterburner.views.FXMLView;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.Objects;

public class RegistrationView extends FXMLView {

    public View getView(){
        try {
            View view = FXMLLoader.load(Objects.requireNonNull(RegistrationView.class.getResource("Registration.fxml")));
            view.getStylesheets().add(Objects.requireNonNull(RegistrationView.class.getResource("Registration.css")).toExternalForm());
            return view;
        } catch (IOException e) {
            return new View();
        }

    }
}
