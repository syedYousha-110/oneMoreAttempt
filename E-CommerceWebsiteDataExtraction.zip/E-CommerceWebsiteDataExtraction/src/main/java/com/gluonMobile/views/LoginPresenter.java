package com.gluonMobile.views;

import com.gluonMobile.model.DataBase;
import com.gluonMobile.model.Enum.RegionalURL;
import com.gluonMobile.model.SignIn;
import com.gluonMobile.model.SignUp;
import com.gluonhq.charm.glisten.animation.BounceInRightTransition;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import static com.gluonMobile.MobileApplication.API_VIEW;
import static com.gluonMobile.MobileApplication.REGISTRATION_VIEW;

public class LoginPresenter {

    private final static String USER ="thorin";
    private final static String PASSWORD="login";
    public View login;
    @FXML
    private Button loginButton;
    @FXML
    private Hyperlink accountUserRegister;

    @FXML
    private PasswordField password;

    @FXML
    private TextField user;
    @FXML
    void showRegisterStage(ActionEvent event) {
            AppManager.getInstance().switchView(REGISTRATION_VIEW);
    }
    public void initialize(){
        user.setText(USER);
        password.setText(PASSWORD);
        SignIn signIn = new SignIn();
        login.setShowTransitionFactory(BounceInRightTransition::new);
        login.showingProperty().addListener(((observableValue, aBoolean, newValue) -> {
            if(newValue){
              AppBar appBar = AppManager.getInstance().getAppBar();
              appBar.setTitle(new Text("SIGN IN"));
            }
        }));
        loginButton.setOnAction(actionEvent -> {
            signIn.setUSER_NAME(user.getText().toLowerCase());
            signIn.setUSER_PASSWORD(password.getText().toLowerCase());
        boolean isTrue = signIn.isMatch();
       // if (user.getText().equalsIgnoreCase(USER)&&password.getText().equalsIgnoreCase(PASSWORD))
        if(isTrue){
            System.out.println("matched");
            AppManager.getInstance().switchView(API_VIEW);
        }else {
            user.clear();
            password.clear();
        }
   });

    }
}
