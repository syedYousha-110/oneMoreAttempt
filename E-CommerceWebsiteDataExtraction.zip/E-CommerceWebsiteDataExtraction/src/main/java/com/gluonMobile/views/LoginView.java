package com.gluonMobile.views;

import com.airhacks.afterburner.views.FXMLView;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.Objects;

public class LoginView extends FXMLView {

    public View getLoginView(){
        try {
            View view = FXMLLoader.load(Objects.requireNonNull(LoginView.class.getResource("login.fxml")));
            return view;
        } catch (IOException e) {
           return new View();
        }
    }
}
