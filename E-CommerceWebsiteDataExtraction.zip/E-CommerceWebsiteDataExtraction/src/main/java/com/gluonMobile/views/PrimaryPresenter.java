package com.gluonMobile.views;

import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;

public class PrimaryPresenter {

    @FXML
    private View primary;

    @FXML
    private Label label;

    public void initialize() {
        primary.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = AppManager.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> 
                        AppManager.getInstance().getDrawer().open()));
                appBar.setTitleText("Primary");
                TextField field = new TextField();
                var design = MaterialDesignIcon.SEARCH.button();
                appBar.getActionItems().add(design);
                design.setOnAction(event -> {
                    appBar.getActionItems().add(field);
                    appBar.getActionItems().remove(design);
                });
                    field.setOnKeyPressed(event -> {
                        if (event.getCode().equals(KeyCode.BACK_SPACE) && field.textProperty().isEmpty().get()){
                        appBar.getActionItems().add(design);
                        appBar.getActionItems().remove(field);}
                    });


            }
        });
    }

    @FXML
    void buttonClick() {
        label.setText("Hello JavaFX Universe!");
    }

}
