package com.gluonMobile.views;

import com.airhacks.afterburner.views.FXMLView;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.Objects;

public class DashboardView extends FXMLView {
    public View getView() {
        try {
            View view = FXMLLoader.load(Objects.requireNonNull(ApiView.class.getResource("dashboard.fxml")));
            return view;
        } catch (IOException e) {
            System.out.println("IOException: " + e);
            return new View();
        }
    }
}
