package com.gluonMobile.views;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.TreeCategoryModel.TreeCategoryNode;
import com.gluonMobile.model.Enum.RegionalURL;
import com.gluonMobile.model.SignIn;
import com.gluonhq.charm.glisten.animation.BounceInRightTransition;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import com.gluonhq.charm.glisten.visual.Swatch;
import com.gluonMobile.model.DarazSellerModel.GetRequest.*;
import com.gluonMobile.model.Enum.APIConstants;
import com.gluonMobile.model.TableModelData.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;


public class ApiPresenter{


    @FXML
    private View Api;
    private String brand;
    private String categoryTree;
    private String categoryAttribute;
    private String orders;
    private String response;
    public TextField ApiUrlText;
    public TextField ApikeyText;
    private TextField search_query;
    @FXML
    private ChoiceBox<String> actionsBox;
    @FXML
    private Button execute;
    @FXML
    private Button btn_previous;
    @FXML
    private Button btn_next;
    @FXML
    private TableView<CustomTableProperty> table_View;
    @FXML
    private TreeView<TreeCategoryNode> categoryTreeView;
    @FXML
    private VBox tableVboxContainer;
    @FXML
    private Label TableLabel;
    @FXML
    private TextField SearchField;
    private List<CustomTableView> tableViews;
    private TableView<CustomTableProperty> newTableView;
    public ObservableList<CustomTableProperty> observableList=null;
    private List<CustomTableProperty> customProperties=null;
    private ListIterator<CustomTableProperty> propertyListIterator=null;
    private CustomTableProperty customTableProperty=null;
    private final List<ObservableList<CustomTableProperty>> tableItemLists = FXCollections.observableArrayList();

    private ListIterator<ObservableList<CustomTableProperty>> iterator=null;
    private ListIterator<CustomTableView> iteratorTable;
    private SortedList<CustomTableProperty> dataSortedList;
    private final BrandTableData getBrandTableData = new BrandTableData();
    private final OrdersTableData ordersTableData = new OrdersTableData();
    private final AttributesTableData attributesTableData = new AttributesTableData();
    private int tableIndex = 0;

    private RegionalURL regionalURL;

    public void initialize() {
        search_query = new TextField();
        search_query.textProperty().bind(SearchField.textProperty());
        observableList = FXCollections.observableArrayList();
        System.out.println(observableList);
        Api.setShowTransitionFactory(BounceInRightTransition::new);
        Api.showingProperty().addListener(((observable, oldValue, newValue) -> {
            if (newValue){
                AppBar app = AppManager.getInstance().getAppBar();
                Swatch.LIGHT_BLUE.assignTo(app.getScene());
                app.setTitle(new Label(" GetRequest"));
                app.setNavIcon(MaterialDesignIcon.MENU.button(e->AppManager.getInstance().getDrawer().open()));
                app.getMenuItems().forEach(x->x.setVisible(false));
            }
        }));
        this.tableViews = new ArrayList<>();
        customProperties = new ArrayList<>();
        tableVboxContainer.getChildren().remove(table_View);
        newTableView = new TableView<>();
        newTableView.setMinHeight(300);
        tableVboxContainer.getChildren().add(newTableView);
        tableIndex = tableVboxContainer.getChildren().indexOf(newTableView);
        ApikeyText.setText(APIConstants.API_KEY.getKey());
        ApiUrlText.setText(APIConstants.USER_NAME.getKey());
        initializer();
        buttonEvent();
        treeTable();
    }
    private void treeTable(){
    }
    private void TextBoxSearchEvent(TextField textField){
        textField.textProperty().unbind();
        textField.textProperty().bind(search_query.textProperty());
            TableLabel.textProperty().bind(customTableProperty.TableName().textProperty());
            TableLabel.textFillProperty().bind(customTableProperty.TableName().fillProperty());
            TableLabel.fontProperty().bind(customTableProperty.TableName().fontProperty());
            textField.deselect();
    }

    private void forward(ActionEvent event){
            search_query.deselect();
        if (iterator.hasNext()){
            newTableView = iteratorTable.next().tableView();
            observableList = iterator.next();
            customTableProperty =  propertyListIterator.next();
            inputTableItems(observableList);
            tableVboxContainer.getChildren().set(tableIndex,newTableView);

        }if(!iterator.hasNext()) {
            customTableProperty =  propertyListIterator.previous();
            iteratorTable.previous();
            iterator.previous();
            btn_next.setDisable(true);
            btn_previous.setDisable(false);
        }

    }

    private void backward(ActionEvent event){
        if (iterator.hasPrevious()) {
            newTableView = iteratorTable.previous().tableView();
            customTableProperty = propertyListIterator.previous();
            tableVboxContainer.getChildren().set(tableIndex,newTableView);
            observableList = iterator.previous();


            btn_next.setDisable(false);
        }if (!iterator.hasPrevious() || iterator.previousIndex()==-1){
            newTableView = iteratorTable.next().tableView();
            tableVboxContainer.getChildren().set(tableIndex,newTableView);
            observableList=iterator.next();
            customTableProperty = propertyListIterator.next();
            btn_previous.setDisable(true);
        }
        inputTableItems(observableList);
    }
    private void pointer(){
        while (iterator.hasNext() ){
            observableList = iterator.next();
            newTableView = iteratorTable.next().tableView();
            customTableProperty = propertyListIterator.next();
            tableVboxContainer.getChildren().set(tableIndex,newTableView);

        }
        customTableProperty = propertyListIterator.previous();
        observableList = iterator.previous();
        newTableView = iteratorTable.previous().tableView();
        tableVboxContainer.getChildren().set(tableIndex,newTableView);

        if (iterator.hasPrevious()){
            btn_previous.setDisable(false);
        }
    }
    public static void tableFunction(TableView<CustomTableProperty> table_View){
        table_View.setTableMenuButtonVisible(true);
        table_View.getColumns().forEach(y->y.setResizable(true));
        table_View.getColumns().forEach(x->x.setPrefWidth(table_View.getPrefWidth()/3));
        table_View.getColumns().forEach(x->x.setMinWidth(150));
        table_View.backgroundProperty().setValue(Background.fill(Color.GRAY));

    }
    private void inputTableItems(ObservableList<CustomTableProperty> item){
        newTableView.setItems(item);
        var text = customTableProperty.searchText(newTableView,dataSortedList);
        TextBoxSearchEvent(text);
        tableVboxContainer.getChildren().set(tableIndex,newTableView);

    }

    private void initializer(){
        ApikeyText.setEditable(false);
        ApiUrlText.setEditable(false);
        setChoiceBox(actionsBox);
        observableList = FXCollections.observableArrayList();
        TableLabel.setContentDisplay(ContentDisplay.CENTER);
        TableLabel.setText("JavaFX TABLE");
        TableLabel.setFont(Font.font(30));
//        Limit.setTextFormatter(new TextFormatter<>(new NumberStringConverter()));
//        OffSet.setTextFormatter(new TextFormatter<>(new NumberStringConverter()));
//        Limit.textProperty().isEmpty().addListener(observable -> {
//                Limit.setText("100");
//                Limit.textProperty().setValue("100");
//        });
    }
    public void setChoiceBox(ChoiceBox<String> actionList) {
        actionList.widthProperty().add(30);
        actionList.setValue("Select Api Call");
        ObservableList<String> stringObservableList = FXCollections.observableArrayList();
        brand = "GetBrands";
        categoryAttribute = "GetCategoryAttribute";
        categoryTree= "GetCategoryTree";
        orders= "GetOrders";
        response= "GetResponse";

        stringObservableList.add(brand);
        stringObservableList.add(categoryAttribute);
        stringObservableList.add(categoryTree);
        stringObservableList.add(orders);
        stringObservableList.add(response);
        actionList.setOnShowing(event -> actionList.setItems(stringObservableList));

//        actionList.setOnAction(event -> gridTextField.visibleProperty().bind(new BooleanBinding() {
//            @Override
//            protected boolean computeValue() {
//                return actionList.getSelectionModel().getSelectedItem().equals(brand);
//            }
//        }));*/
    }
    private void buttonEvent(){
        btn_previous.setOnAction(this::backward);
        btn_next.setOnAction(this::forward);

        btn_next.setDisable(true);
        btn_previous.setDisable(true);

        execute.setOnAction(event -> {
            ApiCall apiCall;
            if(actionsBox.getSelectionModel().getSelectedIndex() == -1)
            {
                return;
            }
            if (actionsBox.getSelectionModel().getSelectedItem().equals(categoryAttribute)){
                GetCategoryAttributes attributes = new GetCategoryAttributes();
                apiCall = new ApiCall(attributes,attributesTableData);
                apiCall.start();
            }
            else if (actionsBox.getSelectionModel().getSelectedItem().equals(orders)){
                GetOrders orders = new GetOrders();
                apiCall = new ApiCall(orders,ordersTableData);
                apiCall.start();
            }else if (actionsBox.getSelectionModel().getSelectedItem().equals(brand)){
                GetBrands brands = new GetBrands();
                brands.setUserID(ApiUrlText.getText());
                brands.setApiKey(ApikeyText.getText());
                brands.setRegionalURL(RegionalURL.PAKISTAN);
                brands.AddParameterOffSet("0");
                brands.AddParameterLimit("1000");
                apiCall = new ApiCall(brands, getBrandTableData);
                apiCall.start();
            }else if (actionsBox.getSelectionModel().getSelectedItem().equals(categoryTree)){
                GetCategoryTree tree = new GetCategoryTree();
                apiCall = new ApiCall(tree,new CategoryTreeAttributes());
                apiCall.start();

                apiCall.setOnSucceeded(workerStateEvent -> {
                            TreeItem<TreeCategoryNode> root = tree.getTreeItem();
                            root.setGraphic(new Label("categories"));
                            root.setExpanded(true);
                           categoryTreeView.setRoot(root);


                        }
                 );

            }

        });


    }
    private void fireEventListener(ApiGetRequest apiGetRequestModel , CustomTableProperty property){
       ObservableList<CustomTableProperty> collection = FXCollections.observableArrayList();
                    boolean b = collection.addAll(apiGetRequestModel.getDataForTable());
                    boolean add = tableItemLists.add(collection);
                    observableList = collection;
                    CustomTableView table = new CustomTableView(property,collection);
                    tableViews.add(table);
                    newTableView = table.tableView();
                    tableFunction(newTableView);
                    iterator = tableItemLists.listIterator();
                    iteratorTable = tableViews.listIterator();
                    customProperties.add(property);
                    propertyListIterator = customProperties.listIterator();
                    if (observableList!=null){
                        pointer();
                        inputTableItems(observableList);}
                    var text =  property.searchText(newTableView,dataSortedList);
                    TextBoxSearchEvent(text);
                    btn_next.setDisable(true);
                    execute.setDisable(false);
    }
   private class ApiCall extends Service<ApiGetRequest> {
        private final ApiGetRequest apiGetRequest;
        private final CustomTableProperty property;
        public ApiCall(ApiGetRequest apiGetRequest, CustomTableProperty property){
          this.apiGetRequest = apiGetRequest;
          this.property = property;
        }
        @Override
        protected Task<ApiGetRequest> createTask() {
            return new Task<>() {
                @Override
                protected ApiGetRequest call() throws Exception {
                    ApiGetRequest api = apiGetRequest;
                    api.start();
                    api.join();
                    return api;
                }
                @Override
                protected void running() {

                }

                @Override
                protected void succeeded() {
                    if (apiGetRequest.isAlive()) {
                        return;
                    }else if(apiGetRequest.getDataForTable().isEmpty()){
                        this.runAndReset();
                        return;
                    }
                    fireEventListener(apiGetRequest,property);
                }
            };
        }
    }
}




