package com.gluonMobile.views;

import com.airhacks.afterburner.views.FXMLView;
import com.gluonhq.charm.glisten.mvc.View;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.Objects;

public class ApiView extends FXMLView {

    private View view;

    @Override
    public View getView() {
        this.view = getApiView();
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }

    public View getApiView() {
        try {
            View FXML= FXMLLoader.load(Objects.requireNonNull(ApiView.class.getResource("Api.fxml")));
            FXML.getStylesheets().add(Objects.requireNonNull(ApiView.class.getResource("api.css")).toExternalForm());
            return FXML;
        } catch (IOException e) {
            System.out.println("IOException: " + e);
            return new View();
        }
    }
}
