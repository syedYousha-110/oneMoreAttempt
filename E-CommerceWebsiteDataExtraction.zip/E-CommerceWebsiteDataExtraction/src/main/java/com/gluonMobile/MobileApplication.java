package com.gluonMobile;

import com.gluonMobile.views.*;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.Swatch;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.*;

import static com.gluonhq.charm.glisten.application.AppManager.HOME_VIEW;

public class MobileApplication extends Application {

    public static final String API_VIEW = "Api View";
    public static final String SCRAPPING_VIEW = "Scrapping View";
    public static final String REGISTRATION_VIEW = "Registration View";
    private static final String LOGIN_VIEW = HOME_VIEW;
    public static final String DASHBOARD_VIEW = "Dashboard View";

    private final AppManager appManager = AppManager.initialize(this::postInit);

    public static MobileApplication mobileApplication;

    public static Map<String,View> viewList = new HashMap<>();

    public static void addViewToList(String viewName,View view){
        viewList.put(viewName,view);
    }

    @Override
    public void init() {
        addViewToList(API_VIEW,  new ApiView().getView());
        addViewToList(LOGIN_VIEW,new LoginView().getLoginView());
        addViewToList(SCRAPPING_VIEW, new ScrappingView().getView());
        addViewToList(REGISTRATION_VIEW,new RegistrationView().getView());
        addViewToList(DASHBOARD_VIEW,new DashboardView().getView());
        DrawerManager.buildDrawer(appManager);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        appManager.start(primaryStage);
        mobileApplication=this;
    }

    private void postInit(Scene scene) {
        Swatch.BLUE.assignTo(scene);
        scene.getStylesheets().add(Objects.requireNonNull(MobileApplication.class.getResource("style.css")).toExternalForm());
        ((Stage) scene.getWindow()).getIcons().add(new Image(Objects.requireNonNull(MobileApplication.class.getResourceAsStream("/icon.png"))));
    }
    public static void main(String[] args) {
        launch(args);
    }
}
