package com.gluonMobile;

import com.gluonMobile.model.Enum.APIConstants;
import com.gluonhq.attach.lifecycle.LifecycleService;
import com.gluonhq.attach.util.Platform;
import com.gluonhq.attach.util.Services;
import com.gluonhq.charm.glisten.application.AppManager;
import com.gluonhq.charm.glisten.application.ViewStackPolicy;
import com.gluonhq.charm.glisten.control.Avatar;
import com.gluonhq.charm.glisten.control.NavigationDrawer;
import com.gluonhq.charm.glisten.control.NavigationDrawer.Item;
import com.gluonhq.charm.glisten.control.NavigationDrawer.ViewItem;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import javafx.beans.binding.Bindings;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.gluonMobile.MobileApplication.*;

public class DrawerManager {

    public static void buildDrawer(AppManager app) {
        viewList.forEach((name,view) -> app.addViewFactory(name,()->view));
        Avatar avatar = new Avatar(21, new Image(Objects.requireNonNull(DrawerManager.class.getResourceAsStream("/com/gluonMobile/views/icons/person.jpg"))));
        VBox vBox = new VBox(10);
        vBox.getChildren().addAll(avatar,new Label("Yousha Sajjad"));
        NavigationDrawer drawer = app.getDrawer();
        NavigationDrawer.Header header = new NavigationDrawer.Header(APIConstants.USER_NAME.getKey(),
                APIConstants.API_KEY.getKey(),vBox);
        drawer.setHeader(header);
        final Item apiItem = new ViewItem("API", MaterialDesignIcon.HOME.graphic(), API_VIEW, ViewStackPolicy.SKIP);
        final Item scrappingItem = new ViewItem("SCRAPPING", MaterialDesignIcon.WEB.graphic(), SCRAPPING_VIEW);
        final Item dashboardItem= new ViewItem("DASHBOARD", MaterialDesignIcon.DASHBOARD.graphic(), DASHBOARD_VIEW);
        drawer.getItems().addAll(apiItem, scrappingItem,dashboardItem);
       Item quitItem = new Item("");
        if (Platform.isDesktop()|| Platform.isAndroid() || Platform.isIOS()) {
            quitItem = new Item("Quit", MaterialDesignIcon.EXIT_TO_APP.graphic());
            quitItem.selectedProperty().addListener((obs, ov, nv) -> {
                if (nv) {
                    Services.get(LifecycleService.class).ifPresent(LifecycleService::shutdown);
                }
            });
        }
        final Item signOut = new Item("LOG OUT",MaterialDesignIcon.REMOVE.graphic());
        drawer.getItems().add(signOut);
        drawer.getItems().add(new Text());
        drawer.getItems().add(quitItem);
        signOut.selectedProperty().addListener(((observableValue, aBoolean, isSelected) -> {
            if (isSelected){
                reset(app);
                List<Node> list = new ArrayList<>(drawer.getItems());
                for (Node n : list){
                    drawer.getItems().remove(n);
                }
                mobileApplication.init();
                AppManager.getInstance().switchView(AppManager.HOME_VIEW);
            }
        }));
        colorProperty(signOut);
        colorProperty(apiItem);
        colorProperty(dashboardItem);
        colorProperty(scrappingItem);
        colorProperty(quitItem);

    }
    public static void reset(AppManager appManager){
        viewList.forEach((name,view)->appManager.removeViewFactory(name));
    }
    public static void colorProperty(Item item){
        item.backgroundProperty().bind(Bindings.when(item.hoverProperty())
                .then(Background.fill(Color.web("#3C99DC"))).otherwise(Background.fill(Color.WHITE)));
    }
}