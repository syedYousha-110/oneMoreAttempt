package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.AttributeModel.Attributes;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head;
import com.gluonMobile.model.TableModelData.AttributesTableData;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;


public class GetCategoryAttributes extends ApiGetRequest {

    public GetCategoryAttributes(){
        super("GetCategoryAttributes");
    }
    @Override
    public void run() {
        super.run();
    }
    @Override
    public void constructData() {
        System.out.println("\nGetCategoryAttributes Class");
        if (getSuccessResponse() == null) {return;}

            this.head = getGson().fromJson(getSuccessResponse()
                    .get("Head").getAsJsonObject(), Head.class);
            JsonElement arrayOfAttributes = getSuccessResponse()
                    .get("Body").getAsJsonArray();
            List<Attributes> attributes = new ArrayList<>();

            arrayOfAttributes.getAsJsonArray()
                    .asList()
                    .forEach(attribute -> attributes
                            .add(gson.fromJson(attribute, Attributes.class)));
            for (Attributes attribute : attributes) {
                this.dataForTable.add(new AttributesTableData(attribute));
            }

    }

}
