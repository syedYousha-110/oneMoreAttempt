package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel;

public interface ICustomData {
     void constructData();
}
