package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.OrderModel;

public class AddressShipping extends AddressBilling {
    public AddressShipping(){

    }
}
