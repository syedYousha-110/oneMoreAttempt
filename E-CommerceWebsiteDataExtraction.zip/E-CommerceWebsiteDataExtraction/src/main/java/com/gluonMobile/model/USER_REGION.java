package com.gluonMobile.model;

public enum USER_REGION{
    PAKISTAN,
    NEPAL,

    BANGLADESH,
    SIR_LANKA,

    MYANMAR


}
