package com.gluonMobile.model.DarazSellerModel.PostRequest;


public class ApiPostRequestModel{

    protected String XML;

    public void Result(){

    }
}
