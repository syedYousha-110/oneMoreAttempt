package com.gluonMobile.model.Enum;

import java.net.MalformedURLException;
import java.net.URL;

public enum RegionalURL {
    PAKISTAN("https://api.sellercenter.daraz.pk/"),
    BANGLADESH("https://api.sellercenter.daraz.com.bd/"),
    SRI_LANKA("https://api.sellercenter.daraz.lk/"),
    NEPAL("https://api.sellercenter.daraz.com.np/"),
    MYANMAR("https://api.sellercenter.shop.com.mm/");

    private final URL url;
    RegionalURL(String url){
        try {
            this.url = new URL(url);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }
    public URL getUrl() {
        return this.url;
    }


}
