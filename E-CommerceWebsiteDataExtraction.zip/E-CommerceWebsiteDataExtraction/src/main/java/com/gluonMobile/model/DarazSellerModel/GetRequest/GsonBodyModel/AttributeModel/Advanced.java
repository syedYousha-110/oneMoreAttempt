package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.AttributeModel;

public class Advanced {
    public Advanced(){

    }
    public int getIs_key_prop() {
        return is_key_prop;
    }

    public void setIs_key_prop(int is_key_prop) {
        this.is_key_prop = is_key_prop;
    }

    private int is_key_prop;

    @Override
    public String toString() {
        return "is_Key_prop ? " + getIs_key_prop();
    }
}
