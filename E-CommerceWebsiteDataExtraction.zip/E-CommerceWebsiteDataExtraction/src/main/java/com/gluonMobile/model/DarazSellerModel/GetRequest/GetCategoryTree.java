package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.TreeCategoryModel.TreeCategoryNode;
import com.gluonMobile.model.Enum.APIConstants;
import com.gluonMobile.model.Enum.Format;
import com.google.gson.JsonElement;
import javafx.scene.control.TreeItem;

import java.util.*;

public class GetCategoryTree extends ApiGetRequest {
    public TreeItem<TreeCategoryNode> getTreeItem() {
        return treeItem;
    }
    private TreeItem<TreeCategoryNode> treeItem;

    public GetCategoryTree(){
        super("GetCategoryTree");
        System.out.println(getCommonParameters());
        System.out.println(getSuccessResponse());
        setDataForTable(new ArrayList<>());
    }
    @Override
    public void run(){
        super.run();
    }

    @Override
    public void constructData() {
        System.out.println("\nGetCategoryTree Class");
        Head head;
        if (getSuccessResponse() == null) {return;}
        head = getGson().fromJson(getSuccessResponse().get("Head").getAsJsonObject(), Head.class);
        setHead(head);
        System.out.println(head);
        JsonElement attributes = getSuccessResponse().get("Body").getAsJsonArray();
        List<TreeCategoryNode> attributeList = new ArrayList<>();

        attributes.getAsJsonArray()
                .asList()
                .forEach(attribute->attributeList.add(
                        getGson().
                                fromJson(attribute, TreeCategoryNode.class)));
        this.treeItem = new TreeItem<>();
        for(TreeCategoryNode parent : attributeList){
        TreeItem<TreeCategoryNode> nodeTreeItem = new TreeItem<>(parent);
        setTreeItem(nodeTreeItem);
        treeItem.getChildren().add(nodeTreeItem);
        }

    }
    public void setTreeItem(TreeItem<TreeCategoryNode>treeNode){
                TreeCategoryNode node = treeNode.getValue();
                if (!node.isLeaf())
                {
                    for (TreeCategoryNode childNode : node.getChildren())
                    {
                        TreeItem<TreeCategoryNode> nodeTreeItem = new TreeItem<>(childNode);
                        treeNode.getChildren().add(nodeTreeItem);
                        setTreeItem(nodeTreeItem);
                    }
                }
    }

}
