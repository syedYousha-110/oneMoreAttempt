package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ProductModel;

public class FblWarehouseInventory extends MultiWarehouseInventory {
    public FblWarehouseInventory(){}
}
