package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.AttributeModel;

import java.util.List;

public class Attributes {
    public Attributes(){}
    private Advanced advanced;
    private String attributeType;
    private String inputType;
    private String isMandatory;
    private String isSaleProp;
    private String label;
    private String name;
    private List<Options> options;
    private int propertyId;

    public Advanced getAdvanced() {
        return advanced;
    }

    public void setAdvanced(Advanced advanced) {
        this.advanced = advanced;
    }

    public String getAttributeType() {
        return attributeType;
    }

    public void setAttributeType(String attributeType) {
        this.attributeType = attributeType;
    }

    public String getInputType() {
        return inputType;
    }

    public void setInputType(String inputType) {
        this.inputType = inputType;
    }

    public String isMandatory() {
        return isMandatory;
    }

    public void setIsMandatory(String isMandatory) {
        this.isMandatory = isMandatory;
    }

    public String isSaleProp() {
        return isSaleProp;
    }

    public void setIsSaleProp(String isSaleProp) {
        this.isSaleProp = isSaleProp;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public List<Options> getOptions() {
        return options;
    }

    public void setOptions(List<Options> options) {
        this.options = options;
    }
}

