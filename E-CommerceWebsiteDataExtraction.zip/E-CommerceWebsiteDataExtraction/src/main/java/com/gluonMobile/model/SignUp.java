package com.gluonMobile.model;

import com.gluonMobile.model.Enum.RegionalURL;

import java.util.Objects;

public class SignUp {
    private String USER_NAME;
    private String USER_PASSWORD;
    private String USER_FIRSTNAME;
    private String USER_LASTNAME;
    private RegionalURL REGION;
    private String USER_APIKEY;
    private String USER_ApiUserEmail;

    private String USER_ConfirmPassword;
    public SignUp(){}
    public SignUp(String USER_NAME,
                  String USER_FIRSTNAME, String USER_LASTNAME,
                  RegionalURL REGION, String USER_APIKEY,
                  String USER_ApiUserEmail, String USER_PASSWORD,
                  String USER_ConfirmPassword) {
        setUSER_NAME( USER_NAME);
        setUSER_FIRSTNAME( USER_FIRSTNAME);
        setUSER_LASTNAME( USER_LASTNAME);
        setREGION(REGION);
        setUSER_APIKEY( USER_APIKEY);
        setUSER_ApiUserEmail( USER_ApiUserEmail);
        setUSER_PASSWORD( USER_PASSWORD);
        setUSER_ConfirmPassword( USER_ConfirmPassword);
        new SignIn(this);
    }
    public boolean isPasswordMatches(){
        return Objects.equals(getUSER_PASSWORD(),getUSER_ConfirmPassword());
    }
    public String getUSER_NAME() {
        return USER_NAME;
    }

    public void setUSER_NAME(String USER_NAME) {
        this.USER_NAME = USER_NAME;
    }

    public String getUSER_PASSWORD() {
        return USER_PASSWORD;
    }

    public void setUSER_PASSWORD(String USER_PASSWORD) {
        this.USER_PASSWORD = USER_PASSWORD;
    }

    public String getUSER_FIRSTNAME() {
        return USER_FIRSTNAME;
    }

    public void setUSER_FIRSTNAME(String USER_FIRSTNAME) {
        this.USER_FIRSTNAME = USER_FIRSTNAME;
    }

    public String getUSER_LASTNAME() {
        return USER_LASTNAME;
    }

    public void setUSER_LASTNAME(String USER_LASTNAME) {
        this.USER_LASTNAME = USER_LASTNAME;
    }

    public RegionalURL getREGION() {
        return REGION;
    }

    public String getUSER_APIKEY() {
        return USER_APIKEY;
    }

    public String getUSER_ApiUserEmail() {
        return USER_ApiUserEmail;
    }

    public String getUSER_ConfirmPassword() {
        return USER_ConfirmPassword;
    }

    public void setUSER_ConfirmPassword(String USER_ConfirmPassword) {
        this.USER_ConfirmPassword = USER_ConfirmPassword;
    }

    public void setREGION(RegionalURL REGION) {
        this.REGION = REGION;
    }

    public void setUSER_APIKEY(String USER_APIKEY) {
        this.USER_APIKEY = USER_APIKEY;
    }

    public void setUSER_ApiUserEmail(String USER_ApiUserEmail) {
        this.USER_ApiUserEmail = USER_ApiUserEmail;
    }

 /*   public static void main(String[] args) {
        var s = new SignUp("Thorin","Yousha","sajjad"
                ,USER_REGION.PAKISTAN,Constants.API_KEY.getKey(),
                "syanstore723@gmail.com","abc","abc"
        );
        System.out.println(s.isPasswordMatches());
        System.out.println(s.getREGION());
    }*/
}
