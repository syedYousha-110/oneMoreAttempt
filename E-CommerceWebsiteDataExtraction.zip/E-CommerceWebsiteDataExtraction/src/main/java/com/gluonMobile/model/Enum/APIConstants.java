package com.gluonMobile.model.Enum;


public enum APIConstants {
    API_KEY("AYQF7dunWQaMNbITI6JJbdtsxhTAOWEqRbrQ-ZfO9_9tq1GQbFZ67gzS"),
    USER_NAME("syanstore723@gmail.com");

    private String key;
    APIConstants(String key){
        this.key = key;
    }
    public String getKey(){
        return key;
    }

}
