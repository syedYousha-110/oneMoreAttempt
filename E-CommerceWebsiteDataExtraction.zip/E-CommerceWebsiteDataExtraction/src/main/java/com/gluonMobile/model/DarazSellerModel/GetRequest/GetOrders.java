package com.gluonMobile.model.DarazSellerModel.GetRequest;


import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.OrderModel.Order;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.OrderModel.OrderInstanceCreator;
import com.gluonMobile.model.Enum.Format;
import com.gluonMobile.model.TableModelData.OrdersTableData;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.List;


public class GetOrders extends ApiGetRequest {
    public GetOrders() {
        super("GetOrders");
    }
    @Override
    public void run() {
        super.run();
    }
    @Override
    public void constructData(){
        System.out.println("\nGetOrderClass");
        if (getSuccessResponse() == null) {return;}
        List<Order> ordersList = new ArrayList<>();
        head =  gson.fromJson(getSuccessResponse().get("Head").getAsJsonObject(), com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head.class);
        System.out.println("head 34 order : "+head);
        gson = new GsonBuilder().registerTypeAdapter(Order.class,new OrderInstanceCreator()).create();
        JsonElement arrayOfBrands = getSuccessResponse().get("Body").getAsJsonObject().get("Orders");
        arrayOfBrands.getAsJsonArray().asList().forEach(order->{
            Order order1 = gson.fromJson(order, Order.class);
            System.out.println("line 39 order ID : "+order1.getOrderId());
            ordersList.add(order1);
        });
        for (Order orders:ordersList){
            System.out.println("first Name line 43"+orders.getCustomerFirstName());
            getDataForTable().add(new OrdersTableData(orders));
        }
    }
}
