package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.BrandModel;

import com.google.gson.InstanceCreator;

import java.lang.reflect.Type;

public class BrandCreator implements InstanceCreator<Brand> {
    @Override
    public Brand createInstance(Type type) {
        return new Brand("","","");
    }
}
