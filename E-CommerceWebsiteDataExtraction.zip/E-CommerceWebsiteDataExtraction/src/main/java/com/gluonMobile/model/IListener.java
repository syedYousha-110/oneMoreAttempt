package com.gluonMobile.model;

public interface IListener {
    void addSellerInfo();

}
