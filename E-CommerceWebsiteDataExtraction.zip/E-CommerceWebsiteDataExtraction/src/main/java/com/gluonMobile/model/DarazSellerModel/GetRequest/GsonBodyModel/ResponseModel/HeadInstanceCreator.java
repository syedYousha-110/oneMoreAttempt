package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel;

import com.google.gson.InstanceCreator;

import java.lang.reflect.Type;

public class HeadInstanceCreator implements InstanceCreator<Head>{
    @Override
    public Head createInstance(Type type) {
        return new Head("","","","",0,"","","");
    }
}
