package com.gluonMobile.model;



import java.util.ArrayList;
import java.util.List;

public class DataBase {
    private static final List<SignUp> database = new ArrayList<>();
    public static List<SignUp> getDatabase() {
        return database;
    }

    public static void addDatabase(SignUp signUp){
        database.add(signUp);
    }
}
