package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.OrderModel;

public class AddressBilling {
    public AddressBilling(){}
    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getAddress1() {
        return Address1;
    }

    public void setAddress1(String address1) {
        Address1 = address1;
    }

    public String getAddress2() {
        return Address2;
    }

    public void setAddress2(String address2) {
        Address2 = address2;
    }

    public String getAddress3() {
        return Address3;
    }

    public void setAddress3(String address3) {
        Address3 = address3;
    }

    public String getAddress4() {
        return Address4;
    }

    public void setAddress4(String address4) {
        Address4 = address4;
    }

    public String getAddress5() {
        return Address5;
    }

    public void setAddress5(String address5) {
        Address5 = address5;
    }

    public String getCustomerEmail() {
        return CustomerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        CustomerEmail = customerEmail;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getPostCode() {
        return PostCode;
    }

    public void setPostCode(String postCode) {
        PostCode = postCode;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getTreeAddressId() {
        return TreeAddressId;
    }

    public void setTreeAddressId(String treeAddressId) {
        TreeAddressId = treeAddressId;
    }

    private String FirstName;
    private String LastName;
    private String Phone;
    private String Address1;
    private String Address2;
    private String Address3;
    private String Address4;
    private String Address5;
    private String CustomerEmail;
    private String City;
    private String PostCode;
    private String Country;
    private String TreeAddressId;

}
