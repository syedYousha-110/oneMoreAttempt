package com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.OrderModel;

import com.google.gson.InstanceCreator;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class OrderInstanceCreator implements InstanceCreator<Order> {
    @Override
    public Order createInstance(Type type) {
        return new Order( "","","","","","","","",false,"","","","",new AddressBilling(),new AddressShipping(),"",0,"","",new ArrayList<>(),0.0,0,0,0.0,"","");
    }
}
