package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ProductModel.Product;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ProductModel.ProductBody;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head;
import com.gluonMobile.model.Enum.Format;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class GetProducts extends ApiGetRequest {

    private List<Product> products;
    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    private GetProducts(Format format, String timeStamp, String userID, String apiKey) {
        super("GetProducts");

    }

    public GetProducts(String userID, String apiKey) {
       this(Format.JSON,getCurrentTimestamp(),userID,apiKey);
    }
    @Override
    public void constructData() {
        System.out.println("\nGetProducts");
        if (getSuccessResponse() == null) {return;}
        System.out.println(getSuccessResponse());
        Head head =  getGson().fromJson(Objects.requireNonNullElseGet(getSuccessResponse().get("Head").getAsJsonObject(), JsonObject::new), Head.class);
        setHead(head);
        JsonElement products = getSuccessResponse().get("Body");
        System.out.println(products.toString());
        ProductBody productBody = getGson().fromJson(products.getAsJsonObject(), ProductBody.class);
        setProducts(new ArrayList<>(productBody.getProducts()));

    }



}
