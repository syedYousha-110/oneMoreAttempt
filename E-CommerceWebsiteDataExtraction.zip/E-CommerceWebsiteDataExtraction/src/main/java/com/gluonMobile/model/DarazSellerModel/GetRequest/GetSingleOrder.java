package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.Enum.Format;

public class GetSingleOrder extends ApiGetRequest {

    public GetSingleOrder(String userID, String apiKey) {
        super("Order");
    }

}
