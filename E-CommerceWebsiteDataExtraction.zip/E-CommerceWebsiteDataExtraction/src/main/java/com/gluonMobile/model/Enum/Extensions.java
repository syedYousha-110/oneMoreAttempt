package com.gluonMobile.model.Enum;

public enum Extensions {

    EXCEL("*.xlsx"),
    CSV("*.csv");

   private String extension;
    Extensions(String extension){
        this.extension = extension;
    }
    public String getExtension(){
        return extension;
    }
}
