package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.BrandModel.Brand;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ICustomData;
import com.gluonMobile.model.Enum.Format;
import com.gluonMobile.model.Enum.RegionalURL;
import com.gluonMobile.model.SignIn;
import com.gluonMobile.model.TableModelData.BrandTableData;
import com.google.gson.*;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class GetBrands extends ApiGetRequest implements ICustomData {

    private String limit;


    public GetBrands() {
        super("GetBrands");
        this.addParameter("Offset","0");
    }
    @Override
    public void run() {
        super.run();
        //execute(this);
    }
    @Override
    public void constructData(){
        System.out.println("\nGetBrands Class");

        if (getSuccessResponse()==null){
            return;
        }
        head = gson.fromJson(getSuccessResponse().get("Head").getAsJsonObject(), com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head.class);

        JsonElement brandListJson = getSuccessResponse().get("Body").getAsJsonObject().get("Brands");

        List<Brand> brands = new ArrayList<>();
        brandListJson.getAsJsonArray().asList().forEach(brand-> brands.add(gson.fromJson(brand, Brand.class)));
        for (Brand brand: brands){
            dataForTable.add(new BrandTableData(String.valueOf(brands.indexOf(brand)),brand.getBrandId(), brand.getName(), brand.getGlobalIdentifier()));
        }
    }


    public String getLimit() {
        return limit;
    }
    public void AddParameterLimit(String limit) {
        if (limit.isEmpty() || limit.isBlank()){
            this.limit = "100";
        }else{
        double value = Double.parseDouble(limit);
        if (value>1000)
        this.limit = String.valueOf(1000);
        else this.limit = limit;}
        addParameter("Limit",getLimit());
    }

}
