package com.gluonMobile.model.DarazSellerModel.GetRequest;


import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ICustomData;

import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.Head;
import com.gluonMobile.model.DarazSellerModel.GetRequest.GsonBodyModel.ResponseModel.HeadInstanceCreator;
import com.gluonMobile.model.Enum.Format;
import com.gluonMobile.model.Enum.RegionalURL;
import com.gluonMobile.model.TableModelData.CustomTableProperty;
import com.google.gson.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

public abstract class ApiGetRequest extends Thread implements ICustomData {

    protected GsonBuilder builder;
    private final HttpClient client;

    public RegionalURL regionalURL;

    private String output;
    private String ScApiHost;
    private Map<String,String> commonParameters;
    private String action;
    private Format format;
    private final String timeStamp;
    private String UserID;
    private final String version = "1.0";
    private static final String HASH_ALGORITHM = "HmacSHA256";
    protected String offSet;
    protected JsonObject successResponse;
    protected Gson gson;
    protected Head head;
    private String apiKey;
    public void setRegionalURL(RegionalURL regionalURL) {
        this.regionalURL = regionalURL;
        this.ScApiHost = regionalURL.getUrl().toExternalForm();
    }
    public String getOutput() {
        return output;
    }

    public String getOffSet() {
        return offSet;
    }

    public void AddParameterOffSet(String offSet) {
        this.offSet = offSet;
    }

    public List<CustomTableProperty> getDataForTable() {
        return dataForTable;
    }

    protected List<CustomTableProperty> dataForTable;

    public void setDataForTable(List<CustomTableProperty> dataForTable) {
        this.dataForTable = dataForTable;
    }
    public void setHead(Head head) {
        this.head = head;
    }

    public Head getHead() {
        return head;
    }
    public ApiGetRequest(String action) {
        this.action = action;
        this.format = Format.JSON;
        this.timeStamp = getCurrentTimestamp();
        this.dataForTable = new ArrayList<>();
        this.commonParameters = new HashMap<>();
        this.client = HttpClient.newHttpClient();
        setCommonParameters(commonParameters);
    }

    public void setCommonParameters(Map<String, String> commonParameters) {
        this.commonParameters = commonParameters;
        addParameter("Timestamp",timeStamp);
        addParameter("Version",version);
        addParameter("Action",action);
        addParameter("Format", getFormat());
    }

    public void addParameter(String Field, String Type){
        this.commonParameters.put(Field,Type);
    }

    public Map<String, String> getCommonParameters() {
        return commonParameters;
    }
    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getFormat() {
        return format.getFormat();
    }

    public void setFormat(Format format) {
        this.format = format;
    }

    public String getUserID() {
        return UserID;
    }
    public void setUserID(String userID) {
        UserID = userID;
        addParameter("UserID",UserID);
    }

    public String getVersion() {
        return version;
    }



    public String GenerateApiRequest() {

        Map<String, String> sortedParams = new TreeMap<>(commonParameters);
        System.out.println(sortedParams);
        String queryString = toQueryString(sortedParams);
        final String signature = HmacDigest(queryString, this.apiKey);
        queryString = queryString.concat("&Signature=".concat(signature));

        output = ScApiHost.concat("?".concat(queryString));
        return output;
    }
    public String toQueryString(Map<String, String> data) {
        StringBuilder params = new StringBuilder();
        for (Map.Entry<String, String> pair : data.entrySet()) {
            params.append(URLEncoder.encode((String) pair.getKey(),
                    StandardCharsets.UTF_8)).append("=");
            params.append(URLEncoder.encode((String) pair.getValue(),
                    StandardCharsets.UTF_8)).append("&");
        }
        if (params.length() > 0) {
            params.deleteCharAt(params.length() - 1);
        }
        return params.toString();
    }
    public String HmacDigest(String msg, String keyString) {
        String digest = null;
        try {
            SecretKeySpec key = new SecretKeySpec((keyString).getBytes(StandardCharsets.UTF_8),HASH_ALGORITHM);
            Mac mac = Mac.getInstance(HASH_ALGORITHM);
            mac.init(key);
            final byte[] bytes = mac.doFinal(msg.getBytes(StandardCharsets.US_ASCII));
            StringBuilder hash = new StringBuilder();
            for (byte aByte : bytes) {
                String hex = Integer.toHexString(0xFF & aByte);
                if (hex.length() == 1) {
                    hash.append('0');
                }
                hash.append(hex);
            }
            digest = hash.toString();
        } catch (InvalidKeyException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return digest;
    }

    public JsonObject getSuccessResponse() {
        return successResponse;
    }

    public Gson getGson() {
        return gson;
    }

    public static String getCurrentTimestamp(){
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ");
        df.setTimeZone(tz);
        return df.format(new Date());
    }

    @Override
    public void run(){
       httpGetRequest();
    }
    private void httpGetRequest() {
        String request = GenerateApiRequest();
        System.out.println(request);
        builder = new GsonBuilder();
        builder.setPrettyPrinting();
        gson = new GsonBuilder().registerTypeAdapter(Head.class, new HeadInstanceCreator()).create();
        try {
            HttpRequest getRequest = HttpRequest.newBuilder().uri(new URI(request)).GET().build();
            HttpResponse<String> response = client.send(getRequest, HttpResponse.BodyHandlers.ofString());
            while (response.statusCode()!=200){
                response = client.send(getRequest,HttpResponse.BodyHandlers.ofString());
                sleep(1000);
            }
            this.output = response.body();
            JsonElement gsonTree = gson.toJsonTree(output);
            JsonObject rootNode = JsonParser.parseString(gsonTree.getAsString()).getAsJsonObject();
            JsonObject details = rootNode.getAsJsonObject();
            JsonElement successResponseNode =  details.get("SuccessResponse").getAsJsonObject();
            this.successResponse = successResponseNode.getAsJsonObject();

        } catch (Exception ignored) {
        }finally {
            constructData();
        }

    }

    public void constructData(){
        System.out.println("abstract class");
    }

}





