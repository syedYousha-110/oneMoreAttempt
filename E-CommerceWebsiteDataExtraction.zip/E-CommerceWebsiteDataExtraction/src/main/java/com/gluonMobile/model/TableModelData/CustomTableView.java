package com.gluonMobile.model.TableModelData;


import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.StringConverter;

import java.util.*;


public class CustomTableView {


    private TableView<CustomTableProperty> tableView ;
    private   ObservableList<CustomTableProperty> dataObservableList;
    private CustomTableProperty customTableProperty;

    public CustomTableView(CustomTableProperty customTableProperty, ObservableList<CustomTableProperty> observableList){
        this.customTableProperty = customTableProperty;
        this.dataObservableList = (observableList);
    }


    private List<TableColumn<CustomTableProperty, StringProperty>> InitializeColumns(){
        if (customTableProperty.getInstance() == null){
            return new ArrayList<>();
        }
        List<TableColumn<CustomTableProperty,StringProperty>> columns = new ArrayList<>();

        for (int i = 0; i< customTableProperty.getInstance().getProperties().size(); i++){

            columns.add(new TableColumn<>(Arrays.asList(customTableProperty.getClass().getDeclaredFields()).get(i).getName()));
            columns.get(i).setCellFactory(y->new TextFieldTableCell<>(getStringConverter()));
            System.out.println(i);
        }
        columns.forEach(x->x.setCellValueFactory(y->y.getValue().getProperties().get(x.getText())));

        return columns;
    }
    public TableView<CustomTableProperty> tableView() {
        createTable();
        return tableView;

    }

    private void createTable() {
        tableView = new TableView<>();
        tableView.getColumns().addAll(InitializeColumns());
        tableView.setItems(dataObservableList);
        tableView.setEditable(true);

    }
    public void passInstanceVar(TableView<CustomTableProperty> tableView){
        tableView.getColumns().addAll(InitializeColumns());
        tableView.setItems(dataObservableList);
        tableView.setEditable(true);
        this.tableView = tableView;
    }

    private static StringConverter getNumberConverter(){
        return new StringConverter<>() {
            @Override
            public String toString(Object o) {
                return Integer.toString((Integer) o);
            }

            @Override
            public Integer fromString(String s) {
                return Integer.parseInt(s);
            }
        };
    }
    private StringConverter<Object> getConverter(){
        return new StringConverter<Object>() {
            @Override
            public String toString(Object o) {
                return o.toString();
            }

            @Override
            public Object fromString(String s) {
                return s;
            }
        };
    }
    private static StringConverter getStringConverter() {

        return new StringConverter<>() {
            @Override
            public String toString(Object o) {
                return o!=null?o.toString():"";
            }

            @Override
            public Object fromString(String s) {

                return s;
            }
        };

    }

}
