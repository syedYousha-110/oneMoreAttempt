package com.gluonMobile.model.DarazSellerModel.GetRequest;

import com.gluonMobile.model.Enum.Format;

public class GetResponse extends ApiGetRequest {
    public GetResponse(String action, Format format, String timeStamp, String userID, String apiKey) {
    super("GetResponse");
    }

    @Override
    public void run() {
        super.run();
    }
}
