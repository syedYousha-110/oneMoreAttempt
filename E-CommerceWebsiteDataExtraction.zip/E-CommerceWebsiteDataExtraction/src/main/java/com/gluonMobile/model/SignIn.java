package com.gluonMobile.model;

import com.gluonMobile.model.Enum.RegionalURL;

public class SignIn {
    private String USER_NAME;
    private String USER_PASSWORD;
    private RegionalURL regionalURL;

    public void setUSER_NAME(String USER_NAME) {
        this.USER_NAME = USER_NAME;
    }
    public void setUSER_PASSWORD(String USER_PASSWORD) {
        this.USER_PASSWORD = USER_PASSWORD;
    }
    public RegionalURL getRegionalURL() {
        return regionalURL;
    }
    public void setRegionalURL(RegionalURL regionalURL) {
        this.regionalURL = regionalURL;
    }
    public SignIn(SignUp signUp) {
        DataBase.addDatabase(signUp);
    }
    public SignIn(){

    }
    public boolean isMatch(){
        boolean isMatch = false;
            for (SignUp entity : DataBase.getDatabase()) {
                boolean isUserMatch = entity.getUSER_NAME().equals(USER_NAME);
                boolean isPassword = entity.getUSER_PASSWORD().equals(USER_PASSWORD);
                boolean isConfirmPassword = entity.getUSER_ConfirmPassword().equals(USER_PASSWORD);
                if (isUserMatch && isPassword && isConfirmPassword) {
                    regionalURL = entity.getREGION();
                    isMatch = true;
                    break;
                }
            }
        return isMatch;
        }
    private void addListener(){
    }
}
